# Load necessary libraries
library(tidyverse)
library(janitor)

# File path
file_path <- "C:/Users/Manna/OneDrive/Documents/ec_utbildning/rprograming/r_prog_ds23-main (2)/r_prog_ds23-main/kunskapskontroll/volvo_v60_data/"

# Import the datasets
data_2018 <- read.csv(paste0(file_path, "Data - 2018 .csv"))
data_2020 <- read.csv(paste0(file_path, "Data - 2020.csv"))
data_2021 <- read.csv(paste0(file_path, "Data - 2021.csv"))
data_2022 <- read.csv(paste0(file_path, "Data - 2022.csv"))
data_2023 <- read.csv(paste0(file_path, "Data - 2023.csv"))

# Function to standardize column names and types
standardize_names <- function(df) {
  df %>%
    clean_names() %>%  # Clean column names
    rename_with(~ str_replace_all(., c(
      "modell_ar" = "modellar",  # If "Modellår" is cleaned to "modell_ar"
      "bransle_hybrid_0_bensin_1_diesel_2" = "bransle",
      "vaxellada_automat_0_munual_1" = "vaxellada",
      "vaxellada_automat_0_manual_1" = "vaxellada",  # Fixing typo and unifying names
      "x_hastkrafter" = "hastkrafter"
    )), everything()) %>%
    mutate(across(everything(), as.character))  # Convert all columns to character type
}

# Apply standardization function to all datasets
data_list <- list(data_2018, data_2020, data_2021, data_2022, data_2023) %>%
  map(standardize_names)

# Combine data without dropping missing values initially
clean_data <- data_list %>%
  bind_rows() %>%
  mutate(
    modellar = as.factor(modellar),
    miltal = as.numeric(str_replace_all(miltal, "[^\\d]", "")),  # Remove non-numeric characters
    hastkrafter = as.numeric(str_replace_all(hastkrafter, "[^\\d]", "")),  # Remove non-numeric characters
    pris = as.numeric(str_replace_all(pris, "[^\\d]", "")),  # Remove non-numeric characters
    vaxellada = factor(vaxellada, levels = c("0", "1"), labels = c("Automatic", "Manual")),
    bransle = factor(bransle, levels = c("0", "1", "2"), labels = c("Hybrid", "Petrol", "Diesel"))
  )

# Summarize missing data before deciding to drop rows
missing_summary <- clean_data %>%
  summarize(across(everything(), ~ sum(is.na(.))))

print(missing_summary)

# Optionally, drop rows with missing values only for critical variables
# clean_data <- clean_data %>%
#   drop_na(modellar, miltal, hastkrafter, pris, vaxellada, bransle)

# Check the structure of the cleaned data
str(clean_data)

# Ensure factors have more than one level before running the regression model
if (nlevels(clean_data$modellar) > 1 & nlevels(clean_data$vaxellada) > 1 & nlevels(clean_data$bransle) > 1) {
  # Perform the regression analysis
  model <- lm(pris ~ modellar + miltal + vaxellada + bransle + hastkrafter, data = clean_data)
  
  # Summary of the regression model
  summary(model)
  
  # Plotting the results to check the relationship
  ggplot(clean_data, aes(x = hastkrafter, y = pris, color = vaxellada)) +
    geom_point() +
    geom_smooth(method = "lm", col = "blue") +
    labs(title = "Price Prediction for Volvo V60", x = "Horsepower", y = "Price")
} else {
  print("One or more factors have less than 2 levels. Regression cannot be performed.")
}

